const form = document.getElementById("requestForm");
const flowStatus = document.getElementById("flowStatus");
const requestStatus = document.getElementById("requestStatus");
const result = document.getElementById("result");

const nodes = [1,2,3,4,5,6].map(n => document.getElementById(`node${n}`));

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function setStatus(el, text, type="idle"){
  el.textContent = text;
  el.className = `status ${type}`;
}

function resetNodes(){
  nodes.forEach(n => n.className = "node");
}

function activate(index){
  nodes[index-1].className = "node active";
}

function done(index){
  nodes[index-1].className = "node done";
}

function fail(index){
  nodes[index-1].className = "node failed";
}

function showResult(data){
  result.className = "result";
  result.innerHTML = `
    <div><b>Request ID</b><span>${data.requestId}</span></div>
    <div><b>Employee</b><span>${data.employee}</span></div>
    <div><b>Employee ID</b><span>${data.employeeId}</span></div>
    <div><b>Department</b><span>${data.department}</span></div>
    <div><b>Laptop</b><span>${data.model}</span></div>
    <div><b>Approval</b><span>${data.approval}</span></div>
    <div><b>Inventory</b><span>${data.inventory}</span></div>
    <div><b>Procurement</b><span>${data.po}</span></div>
  `;
}

form.addEventListener("submit", async e => {
  e.preventDefault();

  const employee = document.getElementById("employee").value.trim();
  const employeeId = document.getElementById("employeeId").value.trim();
  const department = document.getElementById("department").value;
  const model = document.getElementById("model").value;
  const reason = document.getElementById("reason").value.trim();

  resetNodes();
  setStatus(flowStatus,"RUNNING","running");
  setStatus(requestStatus,"PROCESSING","running");
  result.className = "result-empty";
  result.textContent = "Flow Designer is processing the request...";

  activate(1);
  await sleep(700);
  done(1);

  activate(2);
  await sleep(700);

  if(!employee || !employeeId || !department || !model || !reason){
    fail(2);
    setStatus(flowStatus,"FAILED","error");
    setStatus(requestStatus,"VALIDATION FAILED","error");
    result.textContent = "Request validation failed. Please complete all fields.";
    return;
  }
  done(2);

  activate(3);
  await sleep(700);
  done(3);

  activate(4);
  await sleep(800);
  done(4);

  activate(5);
  await sleep(900);
  done(5);

  const requestId = "LAP-" + Math.floor(100000 + Math.random() * 900000);
  const po = "PO-" + Math.floor(10000 + Math.random() * 90000);

  activate(6);
  await sleep(700);
  done(6);

  const data = {
    requestId,
    employee,
    employeeId,
    department,
    model,
    approval: "Approved",
    inventory: "Checked",
    po
  };

  showResult(data);
  setStatus(flowStatus,"COMPLETED","success");
  setStatus(requestStatus,"APPROVED","success");

  console.log("Flow Designer execution:", {
    trigger: "Laptop Request Submitted",
    action1: "Validate Request",
    action2: "Manager Approval",
    action3: "Check Inventory",
    action4: "Create Procurement Order",
    action5: "Notify Employee",
    request: data
  });
});
